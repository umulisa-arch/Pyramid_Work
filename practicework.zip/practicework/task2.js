let numbers = [50, 10, 40, 30, 20];
let sortedDescending = numbers.sort((a, b) => b - a);
console.log(sortedDescending); // [50, 40, 30, 20, 10]
