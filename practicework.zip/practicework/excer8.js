function printNumbers() {
    for (let i = 1; i <= 10; i++) {
        console.log(i);
    }
}

// Call the function to print numbers from 1 to 10
printNumbers();
