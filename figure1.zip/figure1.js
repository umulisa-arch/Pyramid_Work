function printPattern(rows) {
    for (let i = 0; i < rows; i++) {
        console.log("*");
    }
}


const numberOfRows = 5;
printPattern(numberOfRows);
